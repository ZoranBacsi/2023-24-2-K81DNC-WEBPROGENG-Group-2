const task1 = document.querySelector("#task1")
const task2 = document.querySelector("#task2")
const task3 = document.querySelector("#task3")
const task4 = document.querySelector("#task4")

console.log(games)